var searchData=
[
  ['call',['call',['../classzencxx_1_1ticker.html#a17caa261a1846eeda64236d26aae5343',1,'zencxx::ticker::call(Functor, const std::chrono::system_clock::duration, job::start_type=job::start_type::auto_start)'],['../classzencxx_1_1ticker.html#a915b9b973ecfc0f4c3fedf2f045e7b85',1,'zencxx::ticker::call(Functor, const std::chrono::system_clock::time_point)'],['../classzencxx_1_1ticker.html#a3bbafe90edfb3cf19d5bb2ece7cf8d28',1,'zencxx::ticker::call(Functor)'],['../classzencxx_1_1ticker.html#ab367311d1f6e11c628f99f9faafd244b',1,'zencxx::ticker::call(Functor nulary_functor, const std::chrono::system_clock::time_point at_time)'],['../classzencxx_1_1ticker.html#affc336cf903c0c859b518e7b722f7bce',1,'zencxx::ticker::call(Functor nulary_functor, const std::chrono::system_clock::duration interval, job::start_type how2start)']]],
  ['can_5flock',['can_lock',['../classzencxx_1_1thread_1_1details_1_1lock__matrix.html#a272f2cdb669b3e5e5b99cf6a35eb58d3',1,'zencxx::thread::details::lock_matrix::can_lock()'],['../classzencxx_1_1thread_1_1details_1_1lock__matrix_3_01exclusive__lock_01_4.html#a066033d5399904b363cd75c78a870b10',1,'zencxx::thread::details::lock_matrix&lt; exclusive_lock &gt;::can_lock()'],['../classzencxx_1_1thread_1_1details_1_1lock__matrix_3_01rw__lock_01_4.html#a35ef6890ce421ea80e79a1acd4ce8e8e',1,'zencxx::thread::details::lock_matrix&lt; rw_lock &gt;::can_lock()']]],
  ['cancel',['cancel',['../classzencxx_1_1ticker_1_1job.html#ad928d9fb9149f75813434bf4146eb983',1,'zencxx::ticker::job']]],
  ['change_5feffective_5fuser',['change_effective_user',['../namespacezencxx_1_1os.html#a2e803dff6fc326f21d2350e23fc6dc4e',1,'zencxx::os::change_effective_user(const uid_t uid)'],['../namespacezencxx_1_1os.html#ae12c96a6ed5e4e71f8bb7c81abe5a750',1,'zencxx::os::change_effective_user(const std::string &amp;user)']]],
  ['char2hex',['char2hex',['../namespacezencxx.html#aa25e9fab98859eb13530b6eae399ec18',1,'zencxx']]],
  ['char2hex_5fh',['char2hex_h',['../namespacezencxx.html#a0605992c10653b867ef600969e59a096',1,'zencxx']]],
  ['char2hex_5fl',['char2hex_l',['../namespacezencxx.html#abc371d355065da1efb2b7e433e5d68b8',1,'zencxx']]],
  ['clear',['clear',['../classzencxx_1_1os_1_1signal_1_1mask.html#a40c98da62a6e56aec4e0366f86f96e86',1,'zencxx::os::signal::mask']]],
  ['color',['color',['../classzencxx_1_1os_1_1color.html#a2f58c11fcbda3a3eea43345c4f67b1b1',1,'zencxx::os::color']]],
  ['convert',['convert',['../classzencxx_1_1os_1_1charset_1_1converter.html#ad32bb105fa83155069f58cdeeab4133a',1,'zencxx::os::charset::converter::convert()'],['../classzencxx_1_1os_1_1charset_1_1convert.html#ad5cc88cb6b157d2a741793f3a88aa561',1,'zencxx::os::charset::convert::convert()']]],
  ['converter',['converter',['../classzencxx_1_1os_1_1charset_1_1converter.html#a3e72ea8d3249448bffafbaf1aa85f5bc',1,'zencxx::os::charset::converter']]],
  ['create',['create',['../classzencxx_1_1ticker.html#a89addc57ee2348685263e5a2cb0fb4d2',1,'zencxx::ticker']]],
  ['current_5fexception',['current_exception',['../classzencxx_1_1exception.html#a1b9d02d29e2171872877961cd508951e',1,'zencxx::exception']]]
];
