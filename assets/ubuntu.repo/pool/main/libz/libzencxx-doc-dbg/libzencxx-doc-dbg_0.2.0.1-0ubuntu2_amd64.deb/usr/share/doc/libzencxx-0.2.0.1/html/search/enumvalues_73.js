var searchData=
[
  ['scheduled',['scheduled',['../structzencxx_1_1details_1_1registered__job.html#a41dbb07318455858c328722417e9f438a638a6d925c422c868b28b9562498ea1d',1,'zencxx::details::registered_job::scheduled()'],['../classzencxx_1_1ticker_1_1job.html#a89ed8cec485657140629440b3d36473da638a6d925c422c868b28b9562498ea1d',1,'zencxx::ticker::job::scheduled()']]],
  ['scheduled_5ffor_5fremoval',['scheduled_for_removal',['../structzencxx_1_1details_1_1registered__job.html#a41dbb07318455858c328722417e9f438ae9c942d50fee81e0289afb1d00fad1da',1,'zencxx::details::registered_job']]],
  ['set_5fas_5fis',['set_as_is',['../classzencxx_1_1os_1_1signal_1_1mask.html#a6139ea83f32b8c49d7984cbd189a83e0ad8f4c59438cb047bbf7b91dd605ff767',1,'zencxx::os::signal::mask']]],
  ['stale',['stale',['../classzencxx_1_1ticker_1_1job.html#a89ed8cec485657140629440b3d36473da36f34fd8319cf30f8e132ef294c616af',1,'zencxx::ticker::job']]],
  ['stopped',['stopped',['../structzencxx_1_1details_1_1registered__job.html#a41dbb07318455858c328722417e9f438af0a0bfe6bc7d2c58d2989034f83183e0',1,'zencxx::details::registered_job::stopped()'],['../classzencxx_1_1ticker_1_1job.html#a89ed8cec485657140629440b3d36473daf0a0bfe6bc7d2c58d2989034f83183e0',1,'zencxx::ticker::job::stopped()']]]
];
