var searchData=
[
  ['get_5fcurrent',['get_current',['../classzencxx_1_1os_1_1signal_1_1mask.html#a4631ec5f0c36862d4012f54f3c316b3aa3622faddd49719514eaaa9e9629e5fae',1,'zencxx::os::signal::mask']]]
];
