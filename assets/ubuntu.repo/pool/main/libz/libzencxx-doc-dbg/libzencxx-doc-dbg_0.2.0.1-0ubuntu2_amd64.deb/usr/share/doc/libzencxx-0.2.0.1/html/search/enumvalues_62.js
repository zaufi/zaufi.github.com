var searchData=
[
  ['block',['block',['../classzencxx_1_1os_1_1signal_1_1mask.html#a6139ea83f32b8c49d7984cbd189a83e0a347960b1e6973134e76c7766378e5253',1,'zencxx::os::signal::mask']]]
];
