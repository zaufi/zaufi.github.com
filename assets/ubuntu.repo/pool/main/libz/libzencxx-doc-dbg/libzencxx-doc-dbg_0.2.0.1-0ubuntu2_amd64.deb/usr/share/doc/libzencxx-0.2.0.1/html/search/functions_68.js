var searchData=
[
  ['has_5fnested_5fexception',['has_nested_exception',['../classzencxx_1_1exception.html#ab2db9add3a33b37d3b255f9637a936fb',1,'zencxx::exception']]],
  ['hex2char',['hex2char',['../namespacezencxx.html#af188126d0e8d1b71630c31b10a39bd89',1,'zencxx::hex2char(const char c)'],['../namespacezencxx.html#a28a4c1283c13695f24e51dac60916dc8',1,'zencxx::hex2char(const char high, const char low)']]]
];
