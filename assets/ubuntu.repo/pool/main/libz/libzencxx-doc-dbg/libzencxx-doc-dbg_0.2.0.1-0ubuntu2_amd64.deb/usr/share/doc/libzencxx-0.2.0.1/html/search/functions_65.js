var searchData=
[
  ['empty',['empty',['../classzencxx_1_1debug_1_1basic__location.html#aa6df23261e9c0fd366973d2a0a5b914b',1,'zencxx::debug::basic_location::empty()'],['../classzencxx_1_1debug_1_1details_1_1linux__impl_1_1backtrace.html#aa560adec0574fcfb994a4583976feaa9',1,'zencxx::debug::details::linux_impl::backtrace::empty() const noexcept'],['../classzencxx_1_1debug_1_1details_1_1linux__impl_1_1backtrace.html#aa560adec0574fcfb994a4583976feaa9',1,'zencxx::debug::details::linux_impl::backtrace::empty() const noexcept']]],
  ['encode',['encode',['../classzencxx_1_1os_1_1charset_1_1convert.html#a91cd3633118730b9fca1ffc28b4b24a2',1,'zencxx::os::charset::convert']]],
  ['exception',['exception',['../classzencxx_1_1exception.html#a9ae7a357c26a1570ae2538440d7a8ddc',1,'zencxx::exception::exception()'],['../classzencxx_1_1os_1_1exception.html#ab854a4e033bc0657c9a9f00608dd4c45',1,'zencxx::os::exception::exception(const char *const api_function_name)'],['../classzencxx_1_1os_1_1exception.html#ad99674c6da69b9fa384040ccdf20ccca',1,'zencxx::os::exception::exception(const int code, const char *const api_function_name)']]]
];
