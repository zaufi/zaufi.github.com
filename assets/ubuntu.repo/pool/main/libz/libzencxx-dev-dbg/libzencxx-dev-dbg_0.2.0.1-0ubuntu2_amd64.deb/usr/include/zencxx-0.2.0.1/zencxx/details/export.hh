
#ifndef ZENCXX_EXPORT_H
#define ZENCXX_EXPORT_H

#ifdef ZENCXX_STATIC_DEFINE
#  define ZENCXX_EXPORT
#  define ZENCXX_NO_EXPORT
#else
#  ifndef ZENCXX_EXPORT
#    ifdef zencxx_EXPORTS
        /* We are building this library */
#      define ZENCXX_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define ZENCXX_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef ZENCXX_NO_EXPORT
#    define ZENCXX_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef ZENCXX_DEPRECATED
#  define ZENCXX_DEPRECATED __attribute__ ((__deprecated__))
#  define ZENCXX_DEPRECATED_EXPORT ZENCXX_EXPORT __attribute__ ((__deprecated__))
#  define ZENCXX_DEPRECATED_NO_EXPORT ZENCXX_NO_EXPORT __attribute__ ((__deprecated__))
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define ZENCXX_NO_DEPRECATED
#endif

#endif
