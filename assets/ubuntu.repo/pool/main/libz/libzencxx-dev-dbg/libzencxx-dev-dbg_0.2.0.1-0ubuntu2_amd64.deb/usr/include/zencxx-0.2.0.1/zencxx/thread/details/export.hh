
#ifndef ZENCXXTHREAD_EXPORT_H
#define ZENCXXTHREAD_EXPORT_H

#ifdef ZENCXXTHREAD_STATIC_DEFINE
#  define ZENCXXTHREAD_EXPORT
#  define ZENCXXTHREAD_NO_EXPORT
#else
#  ifndef ZENCXXTHREAD_EXPORT
#    ifdef zencxxthread_EXPORTS
        /* We are building this library */
#      define ZENCXXTHREAD_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define ZENCXXTHREAD_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef ZENCXXTHREAD_NO_EXPORT
#    define ZENCXXTHREAD_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef ZENCXXTHREAD_DEPRECATED
#  define ZENCXXTHREAD_DEPRECATED __attribute__ ((__deprecated__))
#  define ZENCXXTHREAD_DEPRECATED_EXPORT ZENCXXTHREAD_EXPORT __attribute__ ((__deprecated__))
#  define ZENCXXTHREAD_DEPRECATED_NO_EXPORT ZENCXXTHREAD_NO_EXPORT __attribute__ ((__deprecated__))
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define ZENCXXTHREAD_NO_DEPRECATED
#endif

#endif
