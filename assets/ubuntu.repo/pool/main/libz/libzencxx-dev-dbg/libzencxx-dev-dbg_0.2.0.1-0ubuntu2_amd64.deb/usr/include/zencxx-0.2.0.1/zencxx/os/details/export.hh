
#ifndef ZENCXXOS_EXPORT_H
#define ZENCXXOS_EXPORT_H

#ifdef ZENCXXOS_STATIC_DEFINE
#  define ZENCXXOS_EXPORT
#  define ZENCXXOS_NO_EXPORT
#else
#  ifndef ZENCXXOS_EXPORT
#    ifdef zencxxos_EXPORTS
        /* We are building this library */
#      define ZENCXXOS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define ZENCXXOS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef ZENCXXOS_NO_EXPORT
#    define ZENCXXOS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef ZENCXXOS_DEPRECATED
#  define ZENCXXOS_DEPRECATED __attribute__ ((__deprecated__))
#  define ZENCXXOS_DEPRECATED_EXPORT ZENCXXOS_EXPORT __attribute__ ((__deprecated__))
#  define ZENCXXOS_DEPRECATED_NO_EXPORT ZENCXXOS_NO_EXPORT __attribute__ ((__deprecated__))
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define ZENCXXOS_NO_DEPRECATED
#endif

#endif
