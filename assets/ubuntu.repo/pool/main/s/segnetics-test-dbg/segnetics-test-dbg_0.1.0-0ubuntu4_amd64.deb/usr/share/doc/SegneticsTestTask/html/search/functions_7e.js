var searchData=
[
  ['_7eservice_5fpool',['~service_pool',['../classcaos_1_1os_1_1service__pool.html#a72de7fecf681ef38fcade3626fec7a80',1,'caos::os::service_pool']]],
  ['_7esimple_5fstorage',['~simple_storage',['../classsegnetics_1_1storage_1_1simple__storage.html#abdc0247120911615c194bed618614317',1,'segnetics::storage::simple_storage']]]
];
