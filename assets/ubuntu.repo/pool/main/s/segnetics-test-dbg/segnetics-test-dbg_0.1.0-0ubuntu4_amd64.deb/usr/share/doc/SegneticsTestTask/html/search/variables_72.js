var searchData=
[
  ['report_5finterval_5fthreshold',['REPORT_INTERVAL_THRESHOLD',['../classsegnetics_1_1storage_1_1simple__storage.html#aeff9e52c456ff91c229f2c56477dfb23',1,'segnetics::storage::simple_storage']]]
];
