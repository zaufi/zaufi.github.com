var searchData=
[
  ['logger_5fsettings',['logger_settings',['../classcaos_1_1log_1_1logger__settings.html',1,'caos::log']]]
];
