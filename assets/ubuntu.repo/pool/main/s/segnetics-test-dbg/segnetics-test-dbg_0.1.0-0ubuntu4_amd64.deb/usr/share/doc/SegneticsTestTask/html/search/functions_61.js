var searchData=
[
  ['accept_5fincoming_5fconnection',['accept_incoming_connection',['../classsegnetics_1_1proto_1_1server.html#ab8ebbdd664fdf92e8fdfa784c657b69a',1,'segnetics::proto::server']]],
  ['application',['application',['../classsegnetics_1_1application.html#ae0708be1a253f315d145857a92109b9a',1,'segnetics::application']]]
];
