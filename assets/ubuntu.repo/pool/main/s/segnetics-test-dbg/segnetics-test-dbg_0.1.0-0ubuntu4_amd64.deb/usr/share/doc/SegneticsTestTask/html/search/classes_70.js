var searchData=
[
  ['patternlayout',['PatternLayout',['../classcaos_1_1log_1_1PatternLayout.html',1,'caos::log']]]
];
