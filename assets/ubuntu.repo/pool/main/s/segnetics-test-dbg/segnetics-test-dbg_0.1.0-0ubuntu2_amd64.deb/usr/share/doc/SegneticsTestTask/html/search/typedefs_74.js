var searchData=
[
  ['time_5fpoint_5ftype',['time_point_type',['../classsegnetics_1_1storage_1_1item.html#afd3f4add08ce9a05471d434f86226a08',1,'segnetics::storage::item']]]
];
