var searchData=
[
  ['changecoloraccordinglevel',['ChangeColorAccordingLevel',['../classcaos_1_1log_1_1ChangeColorAccordingLevel.html#a0626a80519b86199e3a24e46e16e0de9',1,'caos::log::ChangeColorAccordingLevel']]]
];
