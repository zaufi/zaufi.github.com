var searchData=
[
  ['value',['value',['../classsegnetics_1_1storage_1_1item.html#a349ad68fee29deba1409562c0ba523af',1,'segnetics::storage::item::value() const '],['../classsegnetics_1_1storage_1_1item.html#a369c22ddb3aab35ae0e26782e3c2ef97',1,'segnetics::storage::item::value(int v)']]]
];
