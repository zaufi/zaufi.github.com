var searchData=
[
  ['application',['application',['../classsegnetics_1_1application.html',1,'segnetics']]]
];
