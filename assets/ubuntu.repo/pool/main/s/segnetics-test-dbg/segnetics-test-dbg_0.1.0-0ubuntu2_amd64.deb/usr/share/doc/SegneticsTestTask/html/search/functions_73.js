var searchData=
[
  ['schedule_5fnext_5faccept',['schedule_next_accept',['../classsegnetics_1_1proto_1_1server.html#a22b3db35d3c0df849918c4f5e38430e2',1,'segnetics::proto::server']]],
  ['schedule_5frequest_5freading',['schedule_request_reading',['../classsegnetics_1_1proto_1_1server.html#a5e9f4c707bf4b058981778e15876fae7',1,'segnetics::proto::server']]],
  ['select_5fcolor_5fby_5flevel',['select_color_by_level',['../classcaos_1_1log_1_1logger__settings.html#a25a6cc6f99c5dd607dc51b385b69f885',1,'caos::log::logger_settings']]],
  ['select_5fdata_5ffrom_5fdisk',['select_data_from_disk',['../classsegnetics_1_1storage_1_1simple__storage.html#a20e7775b9f4b175517bcf1f0a3231931',1,'segnetics::storage::simple_storage']]],
  ['select_5fdata_5ffrom_5fram',['select_data_from_ram',['../classsegnetics_1_1storage_1_1simple__storage.html#a148e1112e60f4e597b72fc5cf50117b1',1,'segnetics::storage::simple_storage']]],
  ['server',['server',['../classsegnetics_1_1proto_1_1server.html#a6c455b61ac0eedf4b293c69bca360d00',1,'segnetics::proto::server']]],
  ['service',['service',['../classcaos_1_1os_1_1service__pool.html#a4473c7f44866868017f01bf355e8fb41',1,'caos::os::service_pool']]],
  ['service_5fpool',['service_pool',['../classcaos_1_1os_1_1service__pool.html#a28dd19ade4632d8914d6467e8655b8de',1,'caos::os::service_pool']]],
  ['session',['session',['../structsegnetics_1_1proto_1_1details_1_1session.html#ade59d9eda5dc9c13c16f6c399df8a9bd',1,'segnetics::proto::details::session']]],
  ['set',['set',['../classcaos_1_1log_1_1thread__id.html#aa93e725bc9cd73141b9d6c454bde68cb',1,'caos::log::thread_id::set(const std::string &amp;name)'],['../classcaos_1_1log_1_1thread__id.html#a953ff3268b5789c62a71d137550e9647',1,'caos::log::thread_id::set(std::string &amp;&amp;name)']]],
  ['settings',['settings',['../namespacecaos_1_1log.html#aa5ccdc92311f116f9aa4c0a86d1162e7',1,'caos::log']]],
  ['simple_5fstorage',['simple_storage',['../classsegnetics_1_1storage_1_1simple__storage.html#af02690d261658eef3555b0fff9edae36',1,'segnetics::storage::simple_storage::simple_storage(const log4cxx::LoggerPtr, const boost::filesystem::path &amp;, std::weak_ptr&lt; zencxx::ticker &gt; &amp;&amp;)'],['../classsegnetics_1_1storage_1_1simple__storage.html#ab5c4f2d2955f7b8e5f21119680efed07',1,'segnetics::storage::simple_storage::simple_storage(const simple_storage &amp;)=delete'],['../classsegnetics_1_1storage_1_1simple__storage.html#af085f4dbca68b9727ba58972335a5df2',1,'segnetics::storage::simple_storage::simple_storage(simple_storage &amp;&amp;)=default']]]
];
