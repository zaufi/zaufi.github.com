var searchData=
[
  ['main',['main',['../application_8cc.html#a31af2ed614dfa039356240cf6bafcfa3',1,'main(int, const char *const []):&#160;application.cc'],['../requester_8cc.html#a814244b02f6701fd8ead246678bb3dae',1,'main(int argc, const char *const argv[]):&#160;requester.cc']]],
  ['make_5fnew_5fbuffer',['make_new_buffer',['../classsegnetics_1_1storage_1_1simple__storage.html#a7888fdd1fe8b2826922943196048d9cb',1,'segnetics::storage::simple_storage']]]
];
