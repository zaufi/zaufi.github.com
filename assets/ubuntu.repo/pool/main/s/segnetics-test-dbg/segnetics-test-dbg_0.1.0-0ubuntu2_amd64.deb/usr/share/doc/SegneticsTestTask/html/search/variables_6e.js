var searchData=
[
  ['none',['NONE',['../namespacesegnetics_1_1storage.html#ae32925c8db5efb52bfa62c35e2fdcf61',1,'segnetics::storage']]]
];
