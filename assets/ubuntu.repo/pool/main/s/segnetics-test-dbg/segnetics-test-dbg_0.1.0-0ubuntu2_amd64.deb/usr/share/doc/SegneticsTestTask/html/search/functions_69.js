var searchData=
[
  ['is_5fcolor_5fenabled',['is_color_enabled',['../classcaos_1_1log_1_1logger__settings.html#a8289c56c9825b35166c62dd7a32a25a7',1,'caos::log::logger_settings']]],
  ['is_5flog_5fallowed_5fon',['is_log_allowed_on',['../classcaos_1_1log_1_1logger__settings.html#a3452b1a570024d7ccee94b13ac7778c1',1,'caos::log::logger_settings']]],
  ['item',['item',['../classsegnetics_1_1storage_1_1item.html#ab9f114a4f0ca399aa292027087b2a640',1,'segnetics::storage::item::item()=default'],['../classsegnetics_1_1storage_1_1item.html#afc678c6fc4faf15b3218e1198107f81e',1,'segnetics::storage::item::item(const time_point_type t, const int v)']]]
];
