var searchData=
[
  ['newinstance',['newInstance',['../classcaos_1_1log_1_1ChangeColorAccordingLevel.html#af947dcd94b62b628766250d41bede089',1,'caos::log::ChangeColorAccordingLevel::newInstance()'],['../classcaos_1_1log_1_1ThreadName.html#acf4b77a9d5c081fb6ff8c6d6731e1b56',1,'caos::log::ThreadName::newInstance()']]]
];
