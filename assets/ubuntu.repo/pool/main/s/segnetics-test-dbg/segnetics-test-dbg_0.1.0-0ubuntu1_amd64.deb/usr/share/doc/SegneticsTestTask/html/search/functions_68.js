var searchData=
[
  ['handle_5fdata_5frequest',['handle_data_request',['../classsegnetics_1_1application.html#aeff8ae8c117b4e6536d96112d8f61b6f',1,'segnetics::application']]],
  ['handle_5fread',['handle_read',['../classsegnetics_1_1proto_1_1server.html#aec9f972acc88b9d0215fb159b85eeaef',1,'segnetics::proto::server']]]
];
