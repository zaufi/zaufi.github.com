var searchData=
[
  ['buffer_5ftype',['buffer_type',['../classsegnetics_1_1storage_1_1simple__storage.html#a4544b30878cf08446ab3713be529c7e1',1,'segnetics::storage::simple_storage']]]
];
