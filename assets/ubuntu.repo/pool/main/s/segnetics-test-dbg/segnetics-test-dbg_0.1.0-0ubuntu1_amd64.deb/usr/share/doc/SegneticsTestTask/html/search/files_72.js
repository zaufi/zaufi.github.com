var searchData=
[
  ['readme_2emd',['README.md',['../build_2installed_2usr_2local_2share_2doc_2SegneticsTestTask_2README_8md.html',1,'']]],
  ['readme_2emd',['README.md',['../README_8md.html',1,'']]],
  ['report_5fproblem_2ecc',['report_problem.cc',['../report__problem_8cc.html',1,'']]],
  ['report_5fproblem_2ehh',['report_problem.hh',['../report__problem_8hh.html',1,'']]],
  ['requester_2ecc',['requester.cc',['../requester_8cc.html',1,'']]]
];
