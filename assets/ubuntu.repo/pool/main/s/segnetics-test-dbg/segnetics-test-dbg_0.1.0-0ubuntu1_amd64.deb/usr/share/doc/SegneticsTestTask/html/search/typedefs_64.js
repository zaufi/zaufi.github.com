var searchData=
[
  ['data_5frequest_5fsignal_5ftype',['data_request_signal_type',['../classsegnetics_1_1proto_1_1server.html#a973580d295fa682d7a0027037b62d49b',1,'segnetics::proto::server']]]
];
