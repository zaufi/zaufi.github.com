var searchData=
[
  ['_d0_a2_d0_b5_d1_81_d1_82_d0_be_d0_b2_d0_be_d0_b5_20_d0_b7_d0_b0_d0_b4_d0_b0_d0_bd_d0_b8_d0_b5_20segnetics',['Тестовое задание Segnetics',['../md_build_installed_usr_local_share_doc_SegneticsTestTask_README.html',1,'']]],
  ['_d0_a2_d0_b5_d1_81_d1_82_d0_be_d0_b2_d0_be_d0_b5_20_d0_b7_d0_b0_d0_b4_d0_b0_d0_bd_d0_b8_d0_b5_20segnetics',['Тестовое задание Segnetics',['../md_README.html',1,'']]]
];
