var searchData=
[
  ['changecoloraccordinglevel',['ChangeColorAccordingLevel',['../classcaos_1_1log_1_1ChangeColorAccordingLevel.html',1,'caos::log']]]
];
