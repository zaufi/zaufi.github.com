var searchData=
[
  ['buffer_5fcapacity',['BUFFER_CAPACITY',['../classsegnetics_1_1storage_1_1simple__storage.html#a44cbeba5d219d9f3958c1467a7f5a5bb',1,'segnetics::storage::simple_storage']]],
  ['buffer_5fsize',['BUFFER_SIZE',['../classsegnetics_1_1storage_1_1simple__storage.html#a0c64115253da9cdcfdbefacb32c6c830',1,'segnetics::storage::simple_storage']]]
];
