var searchData=
[
  ['details',['details',['../namespacesegnetics_1_1proto_1_1details.html',1,'segnetics::proto']]],
  ['proto',['proto',['../namespacesegnetics_1_1proto.html',1,'segnetics']]],
  ['segnetics',['segnetics',['../namespacesegnetics.html',1,'']]],
  ['storage',['storage',['../namespacesegnetics_1_1storage.html',1,'segnetics']]]
];
