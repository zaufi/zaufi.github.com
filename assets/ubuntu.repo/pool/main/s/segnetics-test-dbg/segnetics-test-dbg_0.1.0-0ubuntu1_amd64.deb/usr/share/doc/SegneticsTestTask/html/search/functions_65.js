var searchData=
[
  ['enable_5fcolor',['enable_color',['../classcaos_1_1log_1_1logger__settings.html#aa89ad10284eebc4de8d9c85d749d7700',1,'caos::log::logger_settings']]],
  ['ensure_5fenough_5fspace',['ensure_enough_space',['../classsegnetics_1_1storage_1_1simple__storage.html#ab31d88fbf6e29478fa72ab21d10a38b6',1,'segnetics::storage::simple_storage']]]
];
